<div class="d-flex justify-content-between align-items-center mb-md-4 mb-3">
    <div class="login__logo">
        <a href="{{ route('home') }}"><img src="{{ getImage(getFilePath('logoFavicon') . '/logo_dark.png') }}" alt="Logo"></a>
    </div>
    <a href="{{ route('home') }}" class="back-to-home">
        <i class="ti ti-home"></i>
    </a>
</div>
