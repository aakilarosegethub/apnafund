@php echo  loadExtension('tawk-chat') @endphp
@php echo  loadExtension('google-analytics') @endphp
@php echo  loadExtension('facebook-messenger') @endphp
    