<tr>
    <td class="no-data-table" colspan="100%">
        <div class="no-data-found">
            <img src="{{ asset('assets/admin/images/no-data.png') }}" alt="{{ __($emptyMessage) }}">
            <span>{{ __($emptyMessage) }}</span>
        </div>
    </td>
</tr>
